For this second project, we apply the following:

Machine Learning.

Supervised Learning.

Unsupervised Learning.

Problem Definition:

Data Collection.

Exploratory Data Analysis (EDA).

Data Processing.

Machine Learning Model.

Model Performance (metrics).

Validation Methods.

Tuning.

Results and Conclusions.

    Definition of the Problem:
Predict if a rotational machine will fail or not and compare the reality vs the predictions based on the models built.

    Data Collection
We collected the required data for this project. Specifically the measures of a rotational machine we had a challenge in understanding the data for which we used research knowledge, we talked to people from the industry and we used visualizations and statistics.

It is also necessary to process the data before implementing it in the model, which includes:

NaN's.

Outliers.

Non-numeric variables.

Dimensionality.

Data Normalization.

This part of the project must be adapted to the data.

    Models, Metrics, and Validation Methods.

At this stage, we will implement the Machine Learning models that best suit the problem and consequently the metrics of each model.

First, we will train different models and calculate all the metrics. Depending on the nature of the problem, we will select the model with the best performance using the three validation methods.

Then, we will perform "Tuning" with GridSearchCV to find the best parameters for the model.

If we are doing a Genetic Algorithm or a Recommender, the objective of this part should be to improve the model to make it more efficient.

    Results and Conclusions

To conclude, we will test the model with completely new data and explain the model's performance and what alternatives we can take to improve the model's performance.

    Storytelling

Finally, we will make a brief presentation from start to finish about the project. This presentation can include:

Project motivations.

Project scope.

Tools or technologies used.

Challenges in each part of the process.

Resolution of each challenge or problem.

An outline of the project.

Visualizations and results.

